import Showcase from './Showcase';
import './App.css';

function App() {
  return (
    <div className='main-wrapper background'>
      <Showcase />
    </div>
  );
}

export default App;