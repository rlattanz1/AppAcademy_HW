function MovieDetails() {
  return (
    <div className='comp purple'>
      <h1>MovieDetails Component</h1>
    </div>
  );
}

export default MovieDetails;