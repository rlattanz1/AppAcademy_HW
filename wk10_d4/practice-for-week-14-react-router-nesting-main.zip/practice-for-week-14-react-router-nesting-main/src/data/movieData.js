export const movies = [
  {
    id: 1,
    title: 'Honest Thief',
    description:
      'Hoping to cut a deal, a professional bank robber agrees to return all the money he stole in exchange for a reduced sentence. But when two FBI agents set him up for murder, he must now go on the run to clear his name and bring them to justice.'
  },
  {
    id: 2,
    title: 'Let Him Go',
    description:
      'Following the loss of their son, a retired sheriff and his wife leave their Montana ranch to rescue their young grandson from the clutches of a dangerous family living off the grid in the Dakotas.'
  },
  {
    id: 3,
    title: 'Freaky',
    description:
      'A mystical, ancient dagger causes a notorious serial killer to magically switch bodies with a 17-year-old girl.'
  },
  {
    id: 4,
    title: 'The Informer',
    description:
      'Recruited by the FBI, ex-con and former special operations soldier Pete Koslow uses his covert skills to try and take down the General - the most powerful crime boss in New York'
  }
];
