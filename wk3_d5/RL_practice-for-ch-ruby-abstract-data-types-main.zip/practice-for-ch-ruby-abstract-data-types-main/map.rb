class Map


    def initialize
        map = []
    end


    def set(key, value)
        map[key] << value if map.none?(key)
    end


    def get(key)
        map[key]
    end

    def delete(key)
        map.delet_at(map[key])
    end

    def show
        map[0]
    end

end
